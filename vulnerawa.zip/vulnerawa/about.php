<html>
<head bg color="pink">
<title>Vulnerawa.com</title>
<h1><center>Welcome to Vulnerawa</center></h1>
</head>
<body bgcolor="pink">
<h4><p align="center">Sql injection is not only possible if there's a login screen. 
Even without login screen data can be inserted into database through the url.GO  
<a href="http://kanishkashowto.com/2013/08/21/website-hacking-url-based-sql-injection/"
 target="_blank">here</a> if you need help.</p </p>
<center>
<b><h2> Vulnerawa's Founders.<br></b>
<?php
    // Suppress Notice warnings, has nothing to do with our tutorial.
    error_reporting (E_ALL ^ E_NOTICE);
     
    // Open a connection and Select the database
    mysql_connect("localhost", "root", "")or die(mysql_error());
    mysql_select_db("vulnerawa")or die(mysql_error());
     
    $id=$_GET['id'];
  //  $id=mysql_real_escape_string($id);
     
if(!isset($id))
          {
            $req=mysql_query("select pid from users");
            while($row=mysql_fetch_assoc($req))
                {
                    print "<a href=about.php?id=$row[pid] > Founder $row[pid]</a></br>";
                }
        }
    else
        {
            $req=mysql_query("select Username,Role from users where pid='$id'")or 
     die($req. "<br/><br/>".mysql_error());
            $row=mysql_fetch_row($req);
             
            print "User details : </br>$row[0] </br>$row[1]";
             
        } 
?>
</body>
</html>