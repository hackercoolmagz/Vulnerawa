<?php
include("index.php");
$con=mysqli_connect("127.0.0.1","root");
//create database
$sql="CREATE DATABASE vulnerawa";


if(mysqli_query($con,$sql))
{
echo "Database vulnerawa created successfully.<br>\n ";
}

else
{
echo " Error creating database:" .mysqli_error($con);
}

$con2=mysqli_connect("127.0.0.1","root","","vulnerawa");
//create table
$sql2="CREATE TABLE users
(
PID INT NOT NULL AUTO_INCREMENT,
PRIMARY KEY(PID),
Username VARCHAR(30),
Password VARCHAR(40),
Role CHAR(30)
)";

if(mysqli_query($con2,$sql2))
{
echo "Table users created successfully.<br>\n";
}

else
{
echo " Error creating table users:" .mysqli_error($con2);
}
 
$con3=mysqli_connect("127.0.0.1","root","","vulnerawa");


$sql3="insert into users(pid,`username`,`password`,`role`) VALUES (1,'Kalyan','123kaly','PHP Expert'),
(2,'chakra','123chak','Network Support'),(3,'Jacob', '123456','Admin')  ";

if (!mysqli_query($con3,$sql3))
{
echo "Error inserting data." .mysqli_error($con3);
}

else
{
    echo("Data inserted successfully");
mysqli_close($con3);
}




?>