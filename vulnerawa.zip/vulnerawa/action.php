<?
login_success();
?>
<html>
<head>
</head>
<body bgcolor="pink">


<center>


<form action="process.php" method="post">
<table border="0" cellspacing="10" bgcolor="lightblue">
<tr>Login Form </tr>
<tr>
<td>Username</td>
<td><input name="username" type="text" id="myusername"></td>
</tr>
<tr>
<td>Password</td>
<td><input name="password" type="password" id="mypassword"> </td>
</tr>
<center>
<tr>
<td>
</td>
<td>
<center><input type="Submit" value="Submit" name="submit" ></center>
</td>
<td>
</tr>
</center>
</form>

</center>

</body>
<p>Try to bypass this login form without username and password.<br>
Go <a href="http://kanishkashowto.com/2013/08/09/website-hacking-login-bypass-using-sql-injection-2" target="_blank">here</a> if you need help.</p>
</html>
