<html>
<head bg color="pink">

<title>shunya.com</title>
<center>  
<form method="get" action="db.php">
<input type="submit" value="CREATE DATABASE">

<h1><center>Welcome to Vulnerawa</center></h1>
</head>
<body bgcolor="black">

<div class="leftmenu">


<?php
include 'menu.php'
?>

   
   
</div>



</table>
<p align="center"><font color="#1ec503" size="4"> <b>Vulnerawa2 is a simple vulnerable web application to simulate a real website.</p>
<p align="center">It has typical website vulnerabilities  </p>
<p align="center">Find them using a scanner or manual testing. Choice is yours</p>
<center>


</center>
</form>
</p>
<marquee behavior="bounce"><blink><b><i>Now:SQL injection, Blind SQL injection, XSS, Password cracking, sniffing and Shell Upload</blink></i></b></marquee>
</body>


  

</html>