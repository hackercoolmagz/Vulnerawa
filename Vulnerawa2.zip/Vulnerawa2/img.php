<?php
error_reporting(E_ERROR);
$language = $_GET['language'];
include($language);
?>