<html>
<form name=\"XSS\" action=\"#\" method=\"GET\">
			<p>What's your name?</p>
			<input type=\"text\" name=\"name\">
			<input type=\"submit\" value=\"Submit\">
		</form>
</html>
