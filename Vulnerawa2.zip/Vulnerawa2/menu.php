<?php
echo '<h1><a href="action.php">Login</a>
<a href="about.php">About</a>
<a href="careers.php">Careers</a>
</h1>'
?>