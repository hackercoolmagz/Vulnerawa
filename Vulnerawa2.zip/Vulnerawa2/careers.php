<html>
<head bg colcor="black">
<h1><center><font color="#1ec503" size="6">Vulnerawa is hiring</center></h1>
</head>
<body bgcolor="black">
<p align="center"><font color="#1ec503" size="5">Vulnerawa are looking for guys with knowledge of HTML,
Javascript and PHP and as always freshers will be preferred.</p>

<p align = "center">
If you think you got the skills, just upload the resume and we 
will get back to you.
</p>

<p align = "center">
But remember not everyone is trying to get hired, some just want to upload shell to hack website.
</p>

<center><form action="upload.php" method="post" enctype="multipart/form-data">
    Select resume to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload resume" name="submit">
</form>

</body>
</html>